'use client';

// Context로 이동되었으므로 re-export만 합니다
export { useLanguage, getTranslatedField } from '@/contexts/LanguageContext';