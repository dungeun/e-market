// API route에서 사용할 공통 dynamic export
export const dynamic = 'force-dynamic'
export const runtime = 'nodejs'